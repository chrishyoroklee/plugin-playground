#!/bin/sh
echo "stand-in install.sh"
